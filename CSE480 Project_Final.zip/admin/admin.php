<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
</head>
<body>
<a href="addpackage.php">Add New Package</a>
</body>
</html>