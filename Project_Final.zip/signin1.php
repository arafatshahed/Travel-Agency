
<!DOCTYPE html>
<html>
<head>
	<title>Sign in</title>
    <meta name="viewport" content="width = device-width">
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="bg"></div>
<form method="post" action="signin.php">
<div class="login-box">
    <h1>login</h1>
    <div class="textbox">
    	<img class="im" src="avatar.png" width="20px">
    	<input type="text" placeholder="Username" name="username"><br><br>
    </div>
    <div class="textbox">
    	<img class="im" src="ps.png" width="20px">
    	<input type="password" placeholder="Password" name="password"><br><br>
    </div>
		<input class= "btn" type="submit" value="Sign In">
	</form>

</body>
</html>